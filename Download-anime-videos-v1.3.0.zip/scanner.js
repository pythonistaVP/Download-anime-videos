(() => {
  "use strict";

  if (window.__davScannerInstalled) {
    return;
  }
  window.__davScannerInstalled = true;

  const KNOWN_HOSTS = /(^|\.)(yummyanime\.tv|yummyani\.me|yani\.tv)$/i;
  const PLAYER_HINT = /kodik|alloha|apbugall|aniboom|sibnet|videocdn|vcdns|video_ext/i;
  const STREAM_HINT = /\.(m3u8|mp4|m4v|webm|mpd|mov|flv)(\?|#|$)/i;

  let scanModule = null;

  function loadScan() {
    if (!scanModule) scanModule = import(chrome.runtime.getURL("lib/scan.js"));
    return scanModule;
  }

  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (!message || message.type !== "dav:scan") return;
    loadScan()
      .then((mod) => {
        sendResponse({ ok: true, result: mod.scanPage(document, location.href) });
      })
      .catch((error) => {
        sendResponse({ ok: false, error: String((error && error.message) || error) });
      });
    return true;
  });

  function quickDetect() {
    if (KNOWN_HOSTS.test(location.hostname)) return false;
    for (const frame of document.querySelectorAll("iframe[src], iframe[data-src]")) {
      const src = frame.getAttribute("src") || frame.getAttribute("data-src") || "";
      if (PLAYER_HINT.test(src) || STREAM_HINT.test(src)) return true;
    }
    for (const node of document.querySelectorAll("video[src], video source[src], a[href]")) {
      const value = node.getAttribute("src") || node.getAttribute("href") || "";
      if (/\.m3u8(\?|#|$)/i.test(value)) return true;
    }
    return false;
  }

  const host = document.createElement("div");
  host.id = "dav-scanner-root";
  host.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483000;";
  document.documentElement.appendChild(host);
  const shadow = host.attachShadow({ mode: "open" });

  shadow.innerHTML = `
    <style>
      :host { all: initial; }
      * { box-sizing: border-box; font-family: "Segoe UI", Roboto, Arial, sans-serif; }
      .launcher {
        display: flex; align-items: center; gap: 8px;
        background: linear-gradient(135deg, #7b3fe4, #2f6bff);
        color: #fff; border: none; border-radius: 999px; padding: 10px 15px;
        font-size: 13px; font-weight: 600; cursor: pointer;
        box-shadow: 0 8px 24px rgba(0,0,0,.35);
      }
      .launcher:hover { filter: brightness(1.08); }
      .panel {
        position: absolute; right: 0; bottom: 52px; width: 360px; max-width: 92vw;
        background: #16171c; color: #e8e8ee; border: 1px solid #2c2e38;
        border-radius: 13px; box-shadow: 0 18px 48px rgba(0,0,0,.55); overflow: hidden;
      }
      .panel[hidden] { display: none; }
      .head { display: flex; align-items: center; justify-content: space-between; padding: 10px 13px; border-bottom: 1px solid #262832; }
      .head b { font-size: 13px; }
      .head button { background: none; border: none; color: #9aa0b4; font-size: 17px; cursor: pointer; line-height: 1; }
      .body { padding: 11px 13px; display: flex; flex-direction: column; gap: 8px; max-height: 58vh; overflow: auto; }
      .hint { font-size: 11.5px; color: #9aa0b4; line-height: 1.45; }
      .item { display: flex; align-items: center; gap: 8px; justify-content: space-between; background: #101116; border: 1px solid #2f313c; border-radius: 9px; padding: 7px 9px; }
      .item div { min-width: 0; }
      .item .name { font-size: 12px; color: #dfe3ee; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 190px; }
      .item .meta { font-size: 10.5px; color: #8d93a8; }
      .item button { background: #e0457b; border: none; color: #fff; border-radius: 7px; padding: 5px 9px; font-size: 11.5px; font-weight: 600; cursor: pointer; }
      .item button.ghost { background: #2b2f3d; }
      .err { color: #ff9aa9; font-size: 12px; }
      .spin { display: inline-block; width: 11px; height: 11px; border: 2px solid #565b70; border-top-color: #fff; border-radius: 50%; animation: spin .8s linear infinite; }
      @keyframes spin { to { transform: rotate(360deg); } }
    </style>
    <button class="launcher" id="launcher" hidden>Найти видео</button>
    <div class="panel" id="panel" hidden>
      <div class="head">
        <b>Download anime videos</b>
        <button id="close" title="Закрыть">×</button>
      </div>
      <div class="body" id="body"></div>
    </div>
  `;

  const launcher = shadow.getElementById("launcher");
  const panel = shadow.getElementById("panel");
  const body = shadow.getElementById("body");

  function key() {
    return "dav-scanner-dismissed:" + location.hostname;
  }

  function dismissed() {
    try {
      return sessionStorage.getItem(key()) === "1";
    } catch {
      return false;
    }
  }

  function dismiss() {
    try {
      sessionStorage.setItem(key(), "1");
    } catch {
      /* нет доступа к sessionStorage */
    }
    host.remove();
  }

  function shortUrl(url) {
    try {
      const parsed = new URL(url);
      const name = parsed.pathname.split("/").filter(Boolean).pop() || "/";
      return parsed.hostname + "/…/" + name.slice(0, 32);
    } catch {
      return String(url).slice(0, 44);
    }
  }

  function send(type, params) {
    return new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type, params }, (response) => {
        const lastError = chrome.runtime.lastError;
        if (lastError) {
          reject(new Error(lastError.message));
          return;
        }
        if (!response || !response.ok) {
          reject(new Error((response && response.error) || "Ошибка расширения"));
          return;
        }
        resolve(response.result);
      });
    });
  }

  async function openManager(params) {
    await send("dav:openManager", params);
    panel.hidden = true;
  }

  function row(entry, action) {
    const wrap = document.createElement("div");
    wrap.className = "item";
    const info = document.createElement("div");
    const name = document.createElement("div");
    name.className = "name";
    name.textContent = entry.playerLabel || entry.label || "поток";
    name.title = entry.url;
    const meta = document.createElement("div");
    meta.className = "meta";
    meta.textContent = shortUrl(entry.url);
    info.append(name, meta);
    const button = document.createElement("button");
    button.textContent = entry.actionLabel || "Скачать";
    if (entry.ghost) button.className = "ghost";
    button.addEventListener("click", action);
    wrap.append(info, button);
    return wrap;
  }

  function renderScan(scan) {
    body.innerHTML = "";
    const streams = (scan.streams || []).filter((item) => item.kind === "hls" || item.kind === "file");
    const players = scan.players || [];
    if (scan.title) {
      const title = document.createElement("div");
      title.className = "hint";
      title.textContent = scan.title;
      body.appendChild(title);
    }
    if (!streams.length && !players.length) {
      const empty = document.createElement("div");
      empty.className = "hint";
      empty.textContent = "Ничего не найдено. Запустите видео на странице и нажмите «Обновить».";
      body.appendChild(empty);
    }
    for (const entry of streams) {
      body.appendChild(
        row(entry, () =>
          openManager({
            m3u8: entry.url,
            title: scan.title || "",
            poster: scan.poster || "",
            source: scan.url || "",
          })
        )
      );
    }
    for (const entry of players) {
      const downloadable = entry.kind === "kodik";
      body.appendChild(
        row(
          {
            url: entry.url,
            playerLabel: entry.label + " · " + entry.host,
            actionLabel: downloadable ? "Скачать" : "Открыть",
            ghost: !downloadable,
          },
          () => {
            if (downloadable) {
              openManager({ player: entry.url, title: scan.title || "", poster: scan.poster || "", source: scan.url || "" });
            } else {
              send("dav:openPlayer", { url: entry.url }).catch(() => {});
              panel.hidden = true;
            }
          }
        )
      );
    }
    const refresh = document.createElement("div");
    refresh.className = "hint";
    refresh.textContent = "Не то? Включите слежение в попапе расширения и запустите видео.";
    body.appendChild(refresh);
  }

  async function runScan() {
    body.innerHTML = '<div class="hint"><span class="spin"></span> ищем потоки…</div>';
    try {
      const mod = await loadScan();
      const scan = mod.scanPage(document, location.href);
      renderScan(scan);
      return scan;
    } catch (error) {
      body.innerHTML = "";
      const node = document.createElement("div");
      node.className = "err";
      node.textContent = String((error && error.message) || error);
      body.appendChild(node);
      return null;
    }
  }

  launcher.addEventListener("click", async () => {
    panel.hidden = false;
    if (!body.childElementCount) await runScan();
  });

  shadow.getElementById("close").addEventListener("click", () => {
    panel.hidden = true;
  });

  async function boot() {
    if (dismissed()) return;
    if (KNOWN_HOSTS.test(location.hostname)) return;
    let interesting = false;
    try {
      interesting = quickDetect();
    } catch {
      interesting = false;
    }
    if (!interesting) {
      const mod = await loadScan().catch(() => null);
      if (mod) {
        const scan = mod.scanPage(document, location.href, { resources: true });
        interesting = scan.streams.some((item) => item.kind === "hls") || scan.players.length > 0;
      }
    }
    if (interesting) launcher.hidden = false;
  }

  chrome.runtime.onMessage.addListener((message) => {
    if (message && message.type === "dav:dismiss") {
      dismiss();
    }
  });

  if (document.readyState === "complete" || document.readyState === "interactive") {
    boot();
  } else {
    document.addEventListener("DOMContentLoaded", boot, { once: true });
  }
})();
