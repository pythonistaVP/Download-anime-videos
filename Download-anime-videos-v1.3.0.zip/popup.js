import { detectSite, isAnimePageUrl, playerDownloadable } from "./lib/sites.js";

const siteTitle = document.getElementById("siteTitle");
const siteSub = document.getElementById("siteSub");
const siteCard = document.getElementById("siteCard");
const openBtn = document.getElementById("openBtn");
const scanBtn = document.getElementById("scanBtn");
const urlInput = document.getElementById("urlInput");
const parseBtn = document.getElementById("parseBtn");
const errorEl = document.getElementById("error");
const versionEl = document.getElementById("version");
const sniffSub = document.getElementById("sniffSub");
const sniffList = document.getElementById("sniffList");
const sniffPermBtn = document.getElementById("sniffPermBtn");
const foundCard = document.getElementById("foundCard");
const foundSub = document.getElementById("foundSub");
const foundList = document.getElementById("foundList");
const newsLink = document.getElementById("newsLink");

versionEl.textContent = "v" + (chrome.runtime.getManifest().version || "1.3.0");

let activeTab = null;
let sniffedStreams = [];

function showError(message) {
  errorEl.textContent = message || "";
  errorEl.hidden = !message;
}

function send(type, params) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, params }, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      if (!response || !response.ok) {
        reject(new Error((response && response.error) || "Не удалось выполнить запрос"));
        return;
      }
      resolve(response.result);
    });
  });
}

async function openManager(params) {
  try {
    await send("dav:openManager", params);
    window.close();
  } catch (error) {
    showError(String((error && error.message) || error));
  }
}

function sniffFor(url) {
  return sniffedStreams.find((item) => item.url === url) || null;
}

function streamParams(url, extra = {}) {
  const sniff = sniffFor(url);
  const params = { ...extra };
  if (url) params.m3u8 = url;
  if (sniff && sniff.referer) params.referer = sniff.referer;
  if (sniff && sniff.headers && Object.keys(sniff.headers).length) params.hdr = JSON.stringify(sniff.headers);
  return params;
}

function describeTab(tab) {
  if (!tab || !tab.url || !/^https?:/i.test(tab.url)) {
    siteCard.className = "card warn";
    siteTitle.textContent = "Откройте страницу аниме";
    siteSub.textContent = "На служебных страницах браузера расширение работать не может.";
    openBtn.disabled = true;
    scanBtn.disabled = true;
    return;
  }
  scanBtn.disabled = false;
  if (!detectSite(tab.url)) {
    siteCard.className = "card warn";
    siteTitle.textContent = tab.title || new URL(tab.url).hostname;
    siteSub.textContent = "Не аниме-сайт из списка. Нажмите «Найти видео на этой странице» — поищем плеер или поток.";
    openBtn.disabled = false;
    return;
  }
  if (!isAnimePageUrl(tab.url)) {
    siteCard.className = "card warn";
    siteTitle.textContent = tab.title || "Страница аниме-сайта";
    siteSub.textContent = "Это не страница аниме — откройте нужный тайтл, или вставьте ссылку вручную.";
    openBtn.disabled = false;
    return;
  }
  siteCard.className = "card ok";
  siteTitle.textContent = tab.title || "Страница аниме";
  siteSub.textContent = "Страница аниме найдена — можно открывать менеджер";
  openBtn.disabled = false;
  chrome.tabs.sendMessage(tab.id, { type: "dav:context" }, (response) => {
    if (chrome.runtime.lastError || !response || !response.ok) return;
    const context = response.context || {};
    if (context.title) siteTitle.textContent = context.title;
    if (context.altTitle) siteSub.textContent = context.altTitle + " · страница аниме найдена";
  });
}

function shortUrl(url) {
  try {
    const parsed = new URL(url);
    const name = parsed.pathname.split("/").filter(Boolean).pop() || parsed.hostname;
    return parsed.hostname + "/…/" + name.slice(0, 36);
  } catch {
    return String(url).slice(0, 46);
  }
}

function makeRow(label, text, buttonLabel, onClick) {
  const row = document.createElement("div");
  row.className = "sniff-row";
  const span = document.createElement("span");
  span.textContent = label ? label + " · " + text : text;
  span.title = text;
  const btn = document.createElement("button");
  btn.className = "btn ghost small";
  btn.textContent = buttonLabel;
  btn.addEventListener("click", onClick);
  row.append(span, btn);
  return row;
}

function renderSniffed(streams) {
  sniffedStreams = streams || [];
  sniffList.innerHTML = "";
  const interesting = sniffedStreams.filter((item) => /\.(m3u8|mp4|m4v|mpd)(\?|#|$)/i.test(item.url || ""));
  if (!interesting.length) {
    sniffSub.textContent = "Пока ничего не найдено. Включите слежение, обновите страницу и запустите видео.";
    return;
  }
  sniffSub.textContent = "Найдено потоков: " + interesting.length;
  for (const item of interesting.slice(-8).reverse()) {
    const mark = /\.m3u8(\?|#|$)/i.test(item.url) ? "HLS" : "файл";
    const secure = item.headers && Object.keys(item.headers).length ? " · с заголовками" : "";
    sniffList.appendChild(
      makeRow(mark + secure, shortUrl(item.url), "Скачать", () => openManager(streamParams(item.url, { title: (activeTab && activeTab.title) || "" })))
    );
  }
}

function loadSniffed() {
  if (!activeTab || typeof activeTab.id !== "number") return;
  send("dav:sniff", { tabId: activeTab.id })
    .then((data) => renderSniffed((data && data.streams) || []))
    .catch(() => {});
}

function renderFound(scan) {
  foundCard.hidden = false;
  foundList.innerHTML = "";
  const streams = (scan.streams || []).filter((item) => item.kind === "hls" || item.kind === "file");
  const players = scan.players || [];
  if (!streams.length && !players.length) {
    foundSub.textContent = "Ничего не нашлось. Запустите видео на странице и нажмите кнопку снова.";
    return;
  }
  foundSub.textContent = scan.title || "Можно скачать:";
  for (const entry of streams) {
    foundList.appendChild(
      makeRow(entry.kind === "hls" ? "HLS" : "файл", shortUrl(entry.url), "Скачать", () =>
        openManager(streamParams(entry.url, { title: scan.title || "", poster: scan.poster || "", source: scan.url || "" }))
      )
    );
  }
  for (const entry of players) {
    const downloadable = playerDownloadable(entry.url) || entry.kind === "kodik";
    foundList.appendChild(
      makeRow(entry.label, entry.host, downloadable ? "Скачать" : "Открыть", async () => {
        if (downloadable) {
          await openManager({ player: entry.url, title: scan.title || "", poster: scan.poster || "", source: scan.url || "" });
        } else {
          try {
            await send("dav:openPlayer", { url: entry.url });
            window.close();
          } catch (error) {
            showError(String((error && error.message) || error));
          }
        }
      })
    );
  }
}

async function requestSniffPermission() {
  if (!activeTab || !activeTab.url) return false;
  let origin = "";
  try {
    origin = new URL(activeTab.url).origin + "/*";
  } catch {
    showError("Не удалось определить адрес вкладки");
    return false;
  }
  try {
    const granted = await chrome.permissions.request({ origins: [origin], permissions: ["webRequest"] });
    if (!granted) {
      sniffSub.textContent = "Доступ не выдан.";
      return false;
    }
    sniffSub.textContent = "Слежение включено. Обновите страницу и запустите видео.";
    return true;
  } catch (error) {
    showError(String((error && error.message) || error));
    return false;
  }
}

async function init() {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  activeTab = tabs && tabs[0] ? tabs[0] : null;
  describeTab(activeTab);
  loadSniffed();
  setInterval(loadSniffed, 1500);

  if (sniffPermBtn) {
    sniffPermBtn.addEventListener("click", async () => {
      await requestSniffPermission();
      loadSniffed();
    });
  }

  scanBtn.addEventListener("click", async () => {
    showError("");
    if (!activeTab || typeof activeTab.id !== "number") return;
    scanBtn.disabled = true;
    scanBtn.textContent = "Ищем видео…";
    try {
      const scan = await send("dav:scan", { tabId: activeTab.id });
      renderFound(scan);
    } catch (error) {
      foundCard.hidden = true;
      showError(String((error && error.message) || error));
    } finally {
      scanBtn.disabled = false;
      scanBtn.textContent = "Найти видео на этой странице";
    }
  });

  openBtn.addEventListener("click", () => {
    const params = {};
    if (activeTab && activeTab.url) params.source = activeTab.url;
    const title = siteTitle.textContent;
    if (title && detectSite((activeTab && activeTab.url) || "")) params.title = title;
    openManager(params);
  });

  parseBtn.addEventListener("click", () => {
    showError("");
    const value = urlInput.value.trim();
    if (!value) {
      showError("Вставьте ссылку на страницу аниме или на поток");
      return;
    }
    let url = value;
    if (!/^https?:\/\//i.test(url)) url = "https://" + url;
    if (/\.(m3u8|mp4|m4v|webm|mov|mpd)(\?|#|$)/i.test(url)) {
      openManager(streamParams(url, { title: "" }));
      return;
    }
    const known = !!detectSite(url);
    if (!known && !/^https?:/i.test(url)) {
      showError("Не похоже на ссылку.");
      return;
    }
    openManager({ source: url.split("#")[0], autorun: known ? "1" : "" });
  });

  urlInput.addEventListener("keydown", (event) => {
    if (event.key === "Enter") parseBtn.click();
  });

  newsLink.addEventListener("click", async (event) => {
    event.preventDefault();
    try {
      await send("dav:openManager", { tab: "whatsnew" });
      window.close();
    } catch (error) {
      showError(String((error && error.message) || error));
    }
  });
}

init();
