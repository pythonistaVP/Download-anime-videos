import { createYaniApi, groupVideos, pickBestMatch, fetchPageInfo, describeDub, episodeRangeLabel } from "./lib/yani.js";
import { parsePage, detectSite, playerKind } from "./lib/sites.js";
import { fetchKodikLinks, pickQuality } from "./lib/kodik.js";
import { downloadHls, downloadDirectFile, isDirectMediaUrl } from "./lib/hls.js";
import { createNet } from "./lib/net.js";
import { ZipWriter } from "./lib/zip.js";
import { openSegmentCache } from "./lib/cache.js";
import { subtitleFileName, buildM3u, buildNfo } from "./lib/library.js";
import { loadSettings, saveSettings, loadQueue, saveQueue, clearQueue, pickPreferredDub } from "./lib/settings.js";
import {
  supportsFileSystemAccess,
  pickDirectory,
  ensurePermission,
  openFileSink,
  getFileSize,
  removeEntry,
  MemorySink,
  downloadBlob,
  opfsRoot,
} from "./lib/sinks.js";
import { idbSet, idbGet, idbAddHistory, idbListHistory, idbClearHistory } from "./lib/idb.js";
import {
  formatBytes,
  formatDuration,
  formatSpeed,
  sanitizeFilename,
  renderTemplate,
  toUint8,
  hashString,
  crc32,
  PauseController,
  pad,
  sleep,
  clamp,
  isAbortError,
} from "./lib/util.js";

const SITE_URL = "https://github.com/pythonistaVP/Download-anime-videos";
const DEV_URL = "https://github.com/pythonistaVP/";
const FOLDER_KEY = "download-anime-videos:folder";
const TAB_KEY = "download-anime-videos:tab";
const NEWS_SEEN_KEY = "download-anime-videos:whatsnew-seen";
const TEMP_DIR = "dav-tmp";
const BITRATE = { 240: 34 * 1024, 360: 52 * 1024, 480: 74 * 1024, 720: 112 * 1024, 1080: 190 * 1024, 1440: 320 * 1024 };
const DEFAULT_DURATION = 1440;

const $ = (id) => document.getElementById(id);
const params = new URLSearchParams(location.search);

const state = {
  settings: null,
  source: params.get("source") || "",
  pretitle: params.get("title") || "",
  preAnimeId: Number(params.get("animeId")) || 0,
  preAnimeAlias: params.get("animeAlias") || "",
  prePlayer: params.get("player") || "",
  preReferer: params.get("referer") || "",
  preHdr: params.get("hdr") || "",
  streamReferer: "",
  streamHeaders: null,
  prePoster: params.get("poster") || "",
  preDub: params.get("dub") || "",
  preQuality: params.get("quality") || "",
  preMode: params.get("mode") || "",
  preEpisodes: params.get("episodes") || "",
  autorun: params.get("autorun") === "1",
  anime: null,
  candidates: [],
  groups: [],
  selectedDub: "",
  qualities: [],
  probeError: "",
  selectedQuality: "max",
  selectedEpisodes: new Set(),
  mode: "files",
  directoryHandle: null,
  folderName: "",
  pendingFolderHandle: null,
  runDir: null,
  tempDir: null,
  jobs: [],
  running: false,
  cancelled: false,
  pause: null,
  abort: null,
  measured: null,
  logLines: [],
  pendingOrigins: new Set(),
  net: null,
  zipWriter: null,
  zipName: "",
  restoreQueue: null,
  history: [],
  lastPersist: 0,
};

const api = createYaniApi({
  fetchImpl: (url, init) => appFetch(url, init),
  onLog: (message) => log(message, "api"),
});

function log(message, tag = "") {
  const time = new Date().toLocaleTimeString("ru-RU");
  state.logLines.push(`[${time}] ${tag ? tag + ": " : ""}${message}`);
  if (state.logLines.length > 600) state.logLines.splice(0, state.logLines.length - 600);
  const node = $("logEl");
  if (node) {
    node.textContent = state.logLines.join("\n");
    node.scrollTop = node.scrollHeight;
  }
}

function setText(id, text) {
  const node = $(id);
  if (node) node.textContent = text == null ? "" : String(text);
}

function setError(message) {
  const node = $("setupError");
  if (!node) return;
  node.textContent = message || "";
  if (message) log(message, "ошибка");
}

function posterUrl(poster) {
  if (!poster) return "";
  if (typeof poster === "string") return poster.startsWith("//") ? "https:" + poster : poster;
  const value = poster.medium || poster.big || poster.small || poster.fullsize || "";
  if (!value) return "";
  return String(value).startsWith("//") ? "https:" + value : String(value);
}

function animeUrl(anime) {
  const slug = anime && (anime.anime_url || anime.url);
  return slug ? "https://yummyani.me/anime/" + slug : "";
}

function originPattern(url) {
  try {
    const parsed = new URL(url, location.href);
    if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return "";
    return parsed.origin + "/*";
  } catch {
    return "";
  }
}

async function hasHostPermission(url) {
  const pattern = originPattern(url);
  if (!pattern || !chrome.permissions || !chrome.permissions.contains) return true;
  try {
    return await chrome.permissions.contains({ origins: [pattern] });
  } catch {
    return true;
  }
}

async function appFetch(input, init) {
  try {
    return await fetch(input, init);
  } catch (error) {
    const url = String(input);
    const pattern = originPattern(url);
    if (pattern && !(await hasHostPermission(url))) {
      state.pendingOrigins.add(new URL(url, location.href).origin);
      showPermissionBar();
    }
    throw error;
  }
}

function showPermissionBar() {
  const host = [...state.pendingOrigins][0];
  setText("permText", `Нужен доступ к ${host}, чтобы скачать видео. Нажмите «Разрешить доступ» и запустите загрузку снова.`);
  const bar = $("permBar");
  if (bar) bar.hidden = false;
}

function episodeKey(episode) {
  const numeric = Number(String(episode.number).replace(/[^\d]/g, ""));
  return numeric > 0 ? numeric : episode.index + 1;
}

function currentGroup() {
  return state.groups.find((group) => group.dubbing === state.selectedDub) || null;
}

function episodesOfGroup() {
  const group = currentGroup();
  return group ? group.episodes : [];
}

function selectedEpisodeObjects() {
  return episodesOfGroup().filter((episode) => state.selectedEpisodes.has(episodeKey(episode)));
}

function qualityLabel(quality) {
  if (quality === "max" || !quality) {
    const best = state.qualities.length ? Math.max(...state.qualities) : 0;
    return best ? "максимум (" + best + "p)" : "максимум";
  }
  return quality + "p";
}

function qualityValue(quality = state.selectedQuality) {
  if (quality === "max" || !quality) {
    return state.qualities.length ? Math.max(...state.qualities) : 720;
  }
  return Number(quality) || 720;
}

function directMaxHeight() {
  const value = Number(state.selectedQuality);
  return Number.isFinite(value) && value > 0 ? value : 0;
}

function bytesPerSecond(quality = state.selectedQuality) {
  const value = qualityValue(quality);
  if (state.measured && state.measured.quality === value && state.measured.rate > 0) return state.measured.rate;
  return BITRATE[value] || BITRATE[720];
}

function episodeSeconds(episode) {
  const duration = Number(episode && episode.duration);
  return duration > 30 ? duration : DEFAULT_DURATION;
}

function estimateEpisodeBytes(episode, quality = state.selectedQuality) {
  return episodeSeconds(episode) * bytesPerSecond(quality);
}

function episodeLabel(episode) {
  const key = episodeKey(episode);
  const max = episodesOfGroup().reduce((acc, item) => Math.max(acc, episodeKey(item)), 0);
  return max >= 10 ? pad(key, 2) : String(key);
}

function templateVars(job = null) {
  const anime = state.anime || {};
  const group = currentGroup();
  return {
    title: anime.title || state.pretitle || "anime",
    title_en: anime.anime_url || "",
    year: anime.year || "",
    season: anime.season || "",
    dub: group ? group.dubbing : state.preDub || "",
    ep: job ? job.label : "01",
    epNum: job ? String(job.number) : "1",
    epTitle: job && job.ep ? job.ep.number : "",
    quality: job && job.quality ? job.quality + "p" : qualityLabel(),
  };
}

function fileNameFor(job) {
  const name = renderTemplate(state.settings.filenameTemplate, templateVars(job));
  let out = sanitizeFilename(name || "video.mp4", "video.mp4");
  if (!/\.[a-z0-9]{2,4}$/i.test(out)) out += ".mp4";
  return out;
}

function folderNameFor() {
  const name = sanitizeFilename(renderTemplate(state.settings.folderTemplate, templateVars(null)), "");
  return name && name !== "video" ? name : "";
}

function zipNameFor() {
  const base = folderNameFor() || sanitizeFilename(state.anime ? state.anime.title : "anime", "anime");
  return base + ".zip";
}

function estimateTotalBytes() {
  const episodes = selectedEpisodeObjects();
  return episodes.reduce((sum, episode) => sum + estimateEpisodeBytes(episode), 0);
}

function updateCandidatePoster(anime) {
  const url = posterUrl(anime && anime.poster) || state.prePoster;
  const node = $("posterImg");
  if (!node) return;
  if (url) {
    node.src = url;
    node.hidden = false;
    node.addEventListener("error", () => { node.hidden = true; }, { once: true });
  } else {
    node.hidden = true;
  }
}

function renderAnime() {
  const anime = state.anime;
  updateCandidatePoster(anime);
  if (!anime) {
    setText("animeTitle", state.pretitle || "Тайтл не выбран");
    setText("animeSub", "Введите название в поиске ниже, чтобы выбрать тайтл.");
    const linkRow = $("animeLinkRow");
    if (linkRow) linkRow.textContent = "";
    return;
  }
  setText("animeTitle", anime.title || state.pretitle || "Аниме");
  const episodes = anime.episodes || {};
  const parts = [];
  if (anime.year) parts.push(anime.year + " год");
  if (episodes.count) parts.push("серий: " + episodes.count + (episodes.aired ? " (вышло " + episodes.aired + ")" : ""));
  parts.push("озвучек: " + state.groups.length);
  setText("animeSub", parts.join(" · "));
  const linkRow = $("animeLinkRow");
  if (linkRow) {
    linkRow.textContent = "";
    const href = animeUrl(anime);
    if (href) {
      const link = document.createElement("a");
      link.href = href;
      link.target = "_blank";
      link.rel = "noreferrer";
      link.textContent = "Открыть страницу на yummyani.me";
      linkRow.appendChild(link);
    }
  }
}

function renderCandidates() {
  const box = $("candidateList");
  if (!box) return;
  box.textContent = "";
  if (!state.candidates.length) {
    const empty = document.createElement("div");
    empty.className = "hint";
    empty.textContent = state.searched ? "Ничего не найдено" : "";
    box.appendChild(empty);
    return;
  }
  for (const candidate of state.candidates) {
    const card = document.createElement("div");
    card.className = "cand" + (state.anime && state.anime.anime_id === candidate.anime_id ? " active" : "");
    const img = document.createElement("img");
    img.alt = "";
    const url = posterUrl(candidate.poster);
    if (url) img.src = url;
    else img.hidden = true;
    const meta = document.createElement("div");
    meta.className = "cand-meta";
    const title = document.createElement("div");
    title.className = "cand-title";
    title.textContent = candidate.title || "Без названия";
    const sub = document.createElement("div");
    sub.className = "cand-sub";
    const bits = [];
    if (candidate.year) bits.push(candidate.year);
    if (candidate.score) bits.push("совпадение " + Math.round(candidate.score * 100) + "%");
    sub.textContent = bits.join(" · ") || "нажмите, чтобы выбрать";
    meta.append(title, sub);
    card.append(img, meta);
    card.addEventListener("click", () => selectAnime(candidate.anime_id));
    box.appendChild(card);
  }
}

function renderDubs() {
  const box = $("dubList");
  if (!box) return;
  box.textContent = "";
  const supported = state.groups.filter((group) => group.supported);
  setText("dubHint", state.groups.length ? `доступно озвучек: ${state.groups.length} (качабельных: ${supported.length})` : "");
  if (!state.groups.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Выберите тайтл, чтобы увидеть список озвучек.";
    box.appendChild(empty);
    return;
  }
  for (const group of state.groups) {
    const info = describeDub(group.dubbing);
    const card = document.createElement("div");
    card.className = "dub" + (group.dubbing === state.selectedDub ? " active" : "") + (group.supported ? "" : " alt");
    const meta = document.createElement("div");
    meta.className = "dub-meta";
    const name = document.createElement("div");
    name.className = "dub-name";
    name.textContent = info.label || group.dubbing;
    const sub = document.createElement("div");
    sub.className = "dub-sub";
    const bits = [info.kind === "subs" ? "субтитры" : info.kind === "single" ? "одноголосая озвучка" : "озвучка"];
    bits.push("серий: " + group.episodeCount);
    if (group.supported) bits.push("плеер " + (group.playerLabel || "Kodik") + " · " + episodeRangeLabel(group.episodes));
    else bits.push("плеер " + (group.playerLabel || "Alloha") + " — через перехватчик");
    sub.textContent = bits.join(" · ");
    meta.append(name, sub);
    card.appendChild(meta);
    card.addEventListener("click", () => selectDub(group.dubbing));
    box.appendChild(card);
  }
  renderPlayerRow();
}

function renderPlayerRow() {
  const row = $("playerRow");
  if (!row) return;
  const group = currentGroup();
  const show = !!(group && !group.supported && group.episodes.length);
  row.hidden = !show;
  if (!show) return;
  const label = group.playerLabel || "плеер";
  setText("playerHint", "У этой озвучки видео в плеере " + label + ". Откройте плеер, включите слежение в попапе и запустите серию — поток появится в списке перехваченных.");
}

function renderQualities() {
  const box = $("qualityChips");
  const hint = $("qualityHint");
  if (!box) return;
  box.textContent = "";
  const list = state.qualities.length ? state.qualities : [360, 480, 720];
  const options = [{ value: "max", label: state.qualities.length ? "максимум" : "максимум (проверим)" }];
  for (const quality of list) options.push({ value: String(quality), label: quality + "p" });
  const totalSeconds = selectedEpisodeObjects().reduce((sum, episode) => sum + episodeSeconds(episode), 0);
  for (const option of options) {
    const chip = document.createElement("span");
    chip.className = "chip" + (String(state.selectedQuality) === option.value ? " active" : "");
    const rate = bytesPerSecond(option.value);
    chip.textContent = option.label + (totalSeconds ? " · ~" + formatBytes(totalSeconds * rate) : "");
    chip.title = "примерный размер на выбранные серии, по реальному битрейту озвучки";
    chip.addEventListener("click", () => {
      state.selectedQuality = option.value;
      renderQualities();
      renderSummary();
    });
    box.appendChild(chip);
  }
  if (hint) {
    if (state.probeError) hint.textContent = "качество не определилось: " + state.probeError;
    else if (state.probeChecking) hint.textContent = "проверяем доступные качества…";
    else if (state.qualities.length) hint.textContent = "в потоке: " + state.qualities.join(", ") + "p";
    else hint.textContent = "";
  }
}

function renderEpisodes() {
  const grid = $("epGrid");
  if (!grid) return;
  grid.textContent = "";
  const episodes = episodesOfGroup();
  const group = currentGroup();
  setText(
    "episodeHint",
    episodes.length ? `${group.dubbing} · ${episodes.length} сер. (${episodeRangeLabel(episodes)})` : ""
  );
  if (!episodes.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Серии появятся после выбора озвучки.";
    grid.appendChild(empty);
    renderSummary();
    return;
  }
  for (const episode of episodes) {
    const key = episodeKey(episode);
    const cell = document.createElement("div");
    cell.className = "ep" + (state.selectedEpisodes.has(key) ? " active" : "");
    cell.textContent = String(key);
    cell.title = "Серия " + key + (episode.duration ? " · " + formatDuration(episode.duration) : "");
    cell.addEventListener("click", () => {
      if (state.selectedEpisodes.has(key)) state.selectedEpisodes.delete(key);
      else state.selectedEpisodes.add(key);
      renderEpisodes();
      renderSummary();
      renderQualities();
    });
    grid.appendChild(cell);
  }
  renderSummary();
}

function renderSummary() {
  const box = $("summary");
  if (!box) return;
  const episodes = selectedEpisodeObjects();
  box.textContent = "";
  if (!episodes.length) {
    box.textContent = "Серии не выбраны.";
    updateControls();
    return;
  }
  const numbers = episodes.map(episodeKey).sort((a, b) => a - b);
  const total = estimateTotalBytes();
  const rows = [
    ["Выбрано серий", episodes.length + " (" + numbers[0] + "–" + numbers[numbers.length - 1] + ")"],
    ["Качество", qualityLabel()],
    ["Примерный размер", "~" + formatBytes(total)],
    ["Как сохранить", state.mode === "zip" ? "один ZIP-архив" : "отдельные MP4-файлы"],
    ["Куда", state.directoryHandle ? "папка «" + state.folderName + "»" + (folderNameFor() ? " / " + folderNameFor() : "") : "загрузки браузера"],
  ];
  for (const [label, value] of rows) {
    const line = document.createElement("div");
    const strong = document.createElement("b");
    strong.textContent = value;
    line.append(label + ": ", strong);
    box.appendChild(line);
  }
  if (!state.directoryHandle && supportsFileSystemAccess()) {
    const warn = document.createElement("div");
    warn.style.color = "#f0b64f";
    warn.textContent = "Совет: выберите папку — файлы будут писаться сразу на диск, и большой сезон не упрётся в память браузера.";
    box.appendChild(warn);
  }
  updateControls();
}

function jobStatusLabel(job) {
  switch (job.status) {
    case "wait": return "в очереди";
    case "links": return "получаем ссылку";
    case "download": return "скачиваем";
    case "ready": return "ждёт упаковки";
    case "zip": return "упаковка";
    case "done": return "готово";
    case "skip": return "пропущено";
    case "error": return "ошибка";
    case "cancelled": return "отменено";
    default: return job.status;
  }
}

function jobBadgeClass(status) {
  if (status === "done" || status === "ready") return "done";
  if (status === "error" || status === "cancelled") return "error";
  if (status === "skip") return "skip";
  if (status === "wait") return "";
  return "active";
}

function jobFraction(job) {
  if (job.status === "done" || job.status === "skip" || job.status === "ready" || job.status === "zip") return 1;
  if (job.segmentsTotal) return clamp(job.segmentsDone / job.segmentsTotal, 0, 1);
  return 0;
}

function updateJobRow(job) {
  if (!job.rowEl) return;
  const { row, badge, fill, left, right, retry } = job.rowEl;
  row.className = "job" + (job.status === "download" || job.status === "links" || job.status === "zip" ? " active" : "") + (job.status === "done" ? " done" : "") + (job.status === "error" ? " error" : "");
  badge.textContent = jobStatusLabel(job) + (job.quality ? " " + job.quality + "p" : "");
  badge.className = "badge" + (jobBadgeClass(job.status) ? " " + jobBadgeClass(job.status) : "");
  fill.style.width = Math.round(jobFraction(job) * 100) + "%";
  const leftParts = [];
  if (job.segmentsTotal) leftParts.push(`${job.segmentsDone}/${job.segmentsTotal} сегм.`);
  if (job.bytes) leftParts.push(formatBytes(job.bytes));
  if (job.rate) leftParts.push(formatSpeed(job.rate));
  left.textContent = job.error ? job.error : (job.detail || leftParts.join(" · "));
  const rightParts = [];
  if (job.eta) rightParts.push("осталось ~" + formatDuration(job.eta));
  if (job.elapsed) rightParts.push(formatDuration(job.elapsed / 1000));
  right.textContent = rightParts.join(" · ");
  retry.hidden = !(job.status === "error" && !state.running);
}

function renderJobs() {
  const box = $("jobList");
  if (!box) return;
  box.textContent = "";
  if (!state.jobs.length) {
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.textContent = "Пока ничего не скачивается";
    box.appendChild(empty);
    renderOverall();
    return;
  }
  for (const job of state.jobs) {
    const row = document.createElement("div");
    row.className = "job";
    const top = document.createElement("div");
    top.className = "job-top";
    const name = document.createElement("div");
    name.className = "job-name";
    name.textContent = "Серия " + job.number + (job.fileName ? " · " + job.fileName : "");
    const badge = document.createElement("span");
    badge.className = "badge";
    top.append(name, badge);
    const bar = document.createElement("div");
    bar.className = "bar";
    const fill = document.createElement("div");
    fill.className = "bar-fill";
    bar.appendChild(fill);
    const sub = document.createElement("div");
    sub.className = "job-sub";
    const left = document.createElement("span");
    const right = document.createElement("span");
    right.className = "right";
    sub.append(left, right);
    const actions = document.createElement("div");
    actions.className = "job-actions";
    const retry = document.createElement("button");
    retry.className = "btn ghost small";
    retry.textContent = "Повторить серию";
    retry.hidden = true;
    retry.addEventListener("click", () => retryJob(job));
    actions.appendChild(retry);
    row.append(top, bar, sub, actions);
    job.rowEl = { row, badge, fill, left, right, retry };
    updateJobRow(job);
    box.appendChild(row);
  }
  renderOverall();
}

function renderOverall() {
  const fill = $("overallFill");
  const stats = $("overallStats");
  if (!fill || !stats) return;
  const jobs = state.jobs;
  if (!jobs.length) {
    fill.style.width = "0%";
    stats.textContent = "Ожидание";
    return;
  }
  const fraction = jobs.reduce((sum, job) => sum + jobFraction(job), 0) / jobs.length;
  fill.style.width = Math.round(fraction * 100) + "%";
  const done = jobs.filter((job) => job.status === "done" || job.status === "skip").length;
  const bytes = jobs.reduce((sum, job) => sum + (job.bytes || 0), 0);
  const estimate = jobs.reduce((sum, job) => sum + (job.estimateBytes || 0), 0);
  const rate = jobs.reduce((sum, job) => sum + (job.rate || 0), 0);
  const parts = [`${done} из ${jobs.length} серий`, formatBytes(bytes) + (estimate ? " из ~" + formatBytes(estimate) : "")];
  if (rate > 0) {
    parts.push(formatSpeed(rate));
    const remaining = Math.max(0, estimate - bytes);
    if (remaining > 0) parts.push("осталось ~" + formatDuration(remaining / rate));
  }
  const errors = jobs.filter((job) => job.status === "error").length;
  if (errors) parts.push("ошибок: " + errors);
  stats.textContent = parts.join(" · ");
  setText("queueHint", state.running ? (state.paused ? "пауза" : "идёт загрузка") : state.jobs.length ? "завершено" : "—");
}

function updateControls() {
  const running = state.running;
  const start = $("startBtn");
  const pause = $("pauseBtn");
  const cancel = $("cancelBtn");
  const clear = $("clearBtn");
  if (start) {
    start.disabled = running;
    start.textContent = running ? "Скачиваем…" : "Скачать";
  }
  if (pause) {
    pause.hidden = !running;
    pause.textContent = state.paused ? "Продолжить" : "Пауза";
  }
  if (cancel) cancel.hidden = !running;
  if (clear) clear.hidden = running || !state.jobs.length;
}

async function selectAnime(animeId) {
  if (!animeId) return;
  setError("");
  setText("animeSub", "загружаем данные…");
  try {
    const anime = await api.anime(animeId);
    state.anime = anime;
    state.preAnimeId = animeId;
    const videos = await api.videos(animeId);
    state.groups = groupVideos(videos);
    state.selectedEpisodes = new Set();
    renderAnime();
    renderCandidates();
    if (!state.groups.length) throw new Error("Для этого тайтла не нашлось серий");
    const supported = state.groups.filter((group) => group.supported);
    const pool = supported.length ? supported : state.groups;
    const names = pool.map((group) => group.dubbing);
    const wanted = state.preDub || pickPreferredDub(names, state.settings.preferredDubs) || names[0];
    state.selectedDub = pool.some((group) => group.dubbing === wanted) ? wanted : names[0];
    renderDubs();
    selectAllEpisodes(true);
    await probeQualities();
    await maybeAutorun();
  } catch (error) {
    setError(String((error && error.message) || error));
    setText("animeSub", "");
  }
}

function selectDub(dubbing) {
  if (dubbing === state.selectedDub) return;
  state.selectedDub = dubbing;
  renderDubs();
  selectAllEpisodes(true);
  probeQualities();
}

function selectAllEpisodes(reset = false) {
  const episodes = episodesOfGroup();
  const keys = episodes.map(episodeKey);
  if (reset) {
    state.selectedEpisodes = new Set(keys);
  } else {
    state.selectedEpisodes = new Set([...state.selectedEpisodes].filter((key) => keys.includes(key)));
  }
  applyEpisodeParam();
  renderEpisodes();
  renderQualities();
}

function applyEpisodeParam() {
  if (!state.preEpisodes) return;
  const keys = episodesOfGroup().map(episodeKey);
  const parsed = parseSelection(state.preEpisodes, keys);
  if (parsed) {
    state.selectedEpisodes = parsed;
    state.preEpisodes = "";
  }
}

function parseSelection(text, available) {
  const value = String(text || "").trim().toLowerCase();
  if (!value) return null;
  if (value === "all" || value === "все") return new Set(available);
  const result = new Set();
  for (const part of value.replace(/\s+/g, "").split(",")) {
    if (!part) continue;
    if (part.includes("-")) {
      const [from, to] = part.split("-");
      const start = Number(from) || Math.min(...available);
      const end = Number(to) || Math.max(...available);
      for (let i = start; i <= end; i++) result.add(i);
    } else {
      const single = Number(part);
      if (Number.isFinite(single)) result.add(single);
    }
  }
  const keep = new Set([...result].filter((item) => available.includes(item)));
  return keep.size ? keep : null;
}

async function probeQualities() {
  const group = currentGroup();
  state.qualities = [];
  state.probeError = "";
  if (!group || !group.episodes.length) {
    renderQualities();
    return;
  }
  if (!group.supported) {
    state.probeError = "плеер " + (group.playerLabel || "Alloha") + " не отдаёт ссылки напрямую";
    log("Озвучка «" + group.dubbing + "» доступна только через плеер " + (group.playerLabel || "Alloha") + ".", "warn");
    renderQualities();
    renderSummary();
    return;
  }
  if (group.direct) {
    state.probeError = "";
    state.qualities = [];
    log("Прямая ссылка: качество выберется из плейлиста по выбранному значению.", "ok");
    renderQualities();
    renderSummary();
    return;
  }
  state.probeChecking = true;
  renderQualities();
  try {
    const links = await fetchKodikLinks(group.episodes[0].url, { fetchImpl: appFetch, retries: 1, onLog: (m) => log(m, "kodik") });
    state.qualities = links.available || [];
    state.defaultQuality = links.defaultQuality;
    if (state.qualities.length) log(`Доступные качества (${group.dubbing}): ${state.qualities.join(", ")}p`, "ok");
  } catch (error) {
    state.probeError = String((error && error.message) || error);
    log("Качество не определилось: " + state.probeError, "warn");
  } finally {
    state.probeChecking = false;
  }
  if (state.preQuality) {
    const numeric = Number(state.preQuality);
    if (state.preQuality === "max") state.selectedQuality = "max";
    else if (Number.isFinite(numeric) && state.qualities.includes(numeric)) state.selectedQuality = String(numeric);
    state.preQuality = "";
  } else if (state.settings.quality && state.settings.quality !== "max") {
    const numeric = Number(state.settings.quality);
    if (Number.isFinite(numeric) && state.qualities.includes(numeric)) state.selectedQuality = String(numeric);
    else state.selectedQuality = "max";
  }
  renderQualities();
  renderSummary();
}

async function searchAnime(query) {
  const cleaned = String(query || "").trim();
  if (!cleaned) return;
  state.searched = true;
  setText("animeSub", "ищем…");
  try {
    const results = await api.search(cleaned);
    const ranked = pickBestMatch(results, state.pretitle || cleaned, state.anime ? state.anime.year : 0)
      .filter((entry) => entry.score > 0.2)
      .sort((a, b) => b.score - a.score)
      .slice(0, 10)
      .map((entry) => ({ ...entry.item, score: entry.score }));
    state.candidates = ranked;
    renderCandidates();
    if (!ranked.length) {
      setError("Ничего не нашлось. Попробуйте другое название.");
      setText("animeSub", "");
      return;
    }
    setText("animeSub", "нашли " + ranked.length + " вариант(ов) — нажмите, чтобы выбрать");
  } catch (error) {
    setError("Поиск не сработал: " + String((error && error.message) || error));
  }
}

function background(type, message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type, params: message }, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      if (!response || !response.ok) {
        reject(new Error((response && response.error) || "Ошибка расширения"));
        return;
      }
      resolve(response.result);
    });
  });
}

async function readSourcePage() {
  if (!state.source) return null;
  const site = detectSite(state.source);
  setText("sourceHint", site ? "читаем страницу " + site.label + "…" : "читаем страницу…");
  try {
    const parsed = await fetchPageInfo(state.source, { fetchImpl: appFetch });
    if (parsed.poster && !state.prePoster) state.prePoster = parsed.poster;
    if (parsed.animeId && site && site.idIsApiId) {
      state.preAnimeId = parsed.animeId;
      state.preAnimeAlias = parsed.animeAlias || state.preAnimeAlias;
    }
    return parsed;
  } catch (error) {
    log("Не удалось прочитать страницу: " + String((error && error.message) || error), "warn");
    return null;
  }
}

async function maybeAutorun() {
  if (!state.autorun || state.autorunDone) return;
  state.autorunDone = true;
  await restoreFolder();
  if (!state.directoryHandle && supportsFileSystemAccess()) {
    setError("Папка не выбрана — нажмите «Выбрать папку» и «Скачать», чтобы начать.");
    log("Автозапуск остановлен: нужна папка для сохранения.", "warn");
    return;
  }
  log("Автозапуск: начинаем загрузку.", "ok");
  await startDownloads();
}

async function restoreFolder() {
  try {
    const handle = await idbGet(FOLDER_KEY);
    if (!handle) return;
    if (typeof handle.getDirectoryHandle !== "function") {
      log("Сохранённая папка больше недоступна — выберите папку заново.", "warn");
      return;
    }
    if (await ensurePermission(handle, "readwrite")) {
      state.directoryHandle = handle;
      state.folderName = handle.name || "папка";
      setText("folderName", state.folderName);
      const perm = $("folderPermBtn");
      if (perm) perm.hidden = true;
      log("Папка восстановлена: " + state.folderName, "ok");
    } else {
      state.pendingFolderHandle = handle;
      setText("folderName", (handle.name || "папка") + " — нужен доступ");
      const perm = $("folderPermBtn");
      if (perm) perm.hidden = false;
      log("Нужно подтвердить доступ к папке «" + (handle.name || "") + "».", "warn");
    }
  } catch (error) {
    log("Не удалось восстановить папку: " + String((error && error.message) || error), "warn");
  }
}

async function chooseFolder() {
  if (!supportsFileSystemAccess()) {
    setError("Этот браузер не умеет писать напрямую в папку — серии пойдут через «Загрузки» браузера.");
    return;
  }
  try {
    const handle = await pickDirectory({ id: "dav-anime", mode: "readwrite" });
    if (!handle) return;
    state.directoryHandle = handle;
    state.folderName = handle.name || "папка";
    state.runDir = null;
    setText("folderName", state.folderName);
    const perm = $("folderPermBtn");
    if (perm) perm.hidden = true;
    setError("");
    try {
      if (state.settings.rememberFolder) await idbSet(FOLDER_KEY, handle);
    } catch {
      /* приватный режим — просто не запоминаем */
    }
    log("Папка сохранения: " + state.folderName, "ok");
    renderSummary();
  } catch (error) {
    if (!isAbortError(error)) setError("Не удалось выбрать папку: " + String((error && error.message) || error));
  }
}

async function grantFolderPermission() {
  if (!state.pendingFolderHandle) return;
  const granted = await ensurePermission(state.pendingFolderHandle, "readwrite");
  if (!granted) {
    setError("Доступ к папке не выдан.");
    return;
  }
  state.directoryHandle = state.pendingFolderHandle;
  state.pendingFolderHandle = null;
  state.folderName = state.directoryHandle.name || "папка";
  setText("folderName", state.folderName);
  const perm = $("folderPermBtn");
  if (perm) perm.hidden = true;
  log("Доступ к папке подтверждён: " + state.folderName, "ok");
  renderSummary();
}

async function ensureRunDir() {
  if (!state.directoryHandle) return null;
  if (state.runDir) return state.runDir;
  const name = folderNameFor();
  if (!name) {
    state.runDir = state.directoryHandle;
    return state.runDir;
  }
  state.runDir = await state.directoryHandle.getDirectoryHandle(name, { create: true });
  log("Подпапка сохранения: " + name);
  return state.runDir;
}

async function ensureTempDir() {
  if (state.tempDir) return state.tempDir;
  const root = await opfsRoot();
  state.tempDir = await root.getDirectoryHandle(TEMP_DIR, { create: true });
  return state.tempDir;
}

async function clearTempDir() {
  try {
    const root = await opfsRoot();
    await removeEntry(root, TEMP_DIR);
  } catch {
    /* нечего чистить */
  }
  state.tempDir = null;
}

function buildJobs() {
  const jobs = [];
  for (const episode of selectedEpisodeObjects()) {
    const number = episodeKey(episode);
    jobs.push({
      ep: episode,
      number,
      key: number,
      label: episodeLabel(episode),
      status: "wait",
      detail: "в очереди",
      bytes: 0,
      segmentsDone: 0,
      segmentsTotal: 0,
      estimateBytes: estimateEpisodeBytes(episode),
      fileName: null,
      rate: 0,
      eta: 0,
    });
  }
  if (jobs.length >= 10) {
    for (const job of jobs) job.label = pad(job.number, 2);
  }
  return jobs;
}

function watchProgress(job, started) {
  let lastTick = Date.now();
  let lastBytes = 0;
  return (progress) => {
    job.segmentsDone = progress.segmentsDone;
    job.segmentsTotal = progress.segmentsTotal;
    job.bytes = progress.writtenBytes || progress.downloadedBytes;
    job.duration = progress.duration;
    const now = Date.now();
    if (now - lastTick >= 800) {
      const rate = (progress.downloadedBytes - lastBytes) / ((now - lastTick) / 1000);
      if (rate > 0) {
        job.rate = rate;
        job.eta = rate > 0 ? Math.max(0, (job.estimateBytes - job.bytes) / rate) : 0;
        state.measured = { quality: qualityValue(job.quality || state.selectedQuality), rate };
      }
      lastTick = now;
      lastBytes = progress.downloadedBytes;
      updateJobRow(job);
      renderOverall();
      updateBadge();
    }
  };
}

async function writeDirFile(dir, name, bytes) {
  const handle = await dir.getFileHandle(name, { create: true });
  const writable = await handle.createWritable();
  await writable.write(bytes);
  await writable.close();
}

async function openEpisodeCache(job, quality) {
  if (!state.settings.resume) return null;
  try {
    return await openSegmentCache(await opfsRoot(), "ep-" + hashString(job.ep.url + "|" + quality));
  } catch {
    return null;
  }
}

async function fetchPosterBytes() {
  const url = posterUrl(state.anime && state.anime.poster) || state.prePoster;
  if (!url) return null;
  try {
    const response = await appFetch(url, { credentials: "omit" });
    if (!response.ok) return null;
    return new Uint8Array(await response.arrayBuffer());
  } catch {
    return null;
  }
}

async function runJob(job, context) {
  const { signal, pause, net } = context;
  job.startedAt = Date.now();
  job.status = "links";
  job.detail = "получаем ссылку на видео";
  job.error = "";
  job.subtitles = [];
  updateJobRow(job);

  const group = currentGroup();
  let quality;
  let playlistUrls;
  let direct = false;
  if (group && group.direct) {
    quality = qualityValue(state.selectedQuality);
    playlistUrls = [job.ep.url];
    direct = true;
    job.status = "download";
    job.detail = isDirectMediaUrl(job.ep.url) ? "скачиваем файл" : "скачиваем прямую ссылку";
  } else {
    const links = await fetchKodikLinks(job.ep.url, {
      fetchImpl: appFetch,
      signal,
      retries: 2,
      onLog: (message) => log(message, "kodik"),
    });
    quality = pickQuality(links.qualities, state.selectedQuality) || state.qualities[0];
    if (!quality) throw new Error("плеер не отдал ни одного качества");
    playlistUrls = (links.mirrors && links.mirrors[quality]) || [links.qualities[quality]];
    job.status = "download";
    job.detail = "скачиваем";
  }
  job.quality = quality;
  job.fileName = fileNameFor(job);
  updateJobRow(job);

  const onProgress = watchProgress(job, job.startedAt);
  const common = {
    playlistUrl: playlistUrls,
    fetchImpl: appFetch,
    concurrency: Math.max(2, state.settings.concurrency || 4),
    net,
    signal,
    pause,
    onProgress,
    subtitles: state.settings.saveSubtitles ? "all" : "none",
    onLog: (message) => log("серия " + job.number + ": " + message, "hls"),
    referrer: state.streamReferer,
    headers: state.streamHeaders,
    maxHeight: direct ? directMaxHeight() : 0,
  };

  const streamTo = (sink, options) =>
    direct && isDirectMediaUrl(job.ep.url)
      ? downloadDirectFile({
          url: job.ep.url,
          sink,
          fetchImpl: appFetch,
          net,
          signal,
          pause,
          onProgress,
          referrer: state.streamReferer,
          headers: state.streamHeaders,
          onLog: (message) => log("серия " + job.number + ": " + message, "файл"),
        })
      : downloadHls({ ...common, sink, ...(options || {}) });

  if (context.mode === "zip") {
    if (!context.zipWriter) throw new Error("ZIP-архив не открыт");
    const entry = context.zipWriter.openEntry(job.fileName);
    try {
      await streamTo(entry, {
        onSubtitle: async (track, text) => {
          const name = subtitleFileName(job.fileName, track);
          await context.zipWriter.addText(name, text);
          job.subtitles.push(name);
        },
      });
      job.bytes = await entry.close();
    } catch (error) {
      await entry.abort();
      throw error;
    }
    job.status = "done";
    job.detail = "в архиве " + state.zipName;
  } else {
    const cache = direct && isDirectMediaUrl(job.ep.url) ? null : await openEpisodeCache(job, quality);
    let dir = null;
    let memory = null;
    let sink;
    if (state.directoryHandle) {
      dir = await ensureRunDir();
      sink = await openFileSink(dir, job.fileName);
    } else {
      memory = new MemorySink();
      sink = memory;
    }
    try {
      const result = await streamTo(sink, {
        cache,
        keepCache: true,
        onSubtitle: async (track, text) => {
          const name = subtitleFileName(job.fileName, track);
          const bytes = new TextEncoder().encode(text);
          if (dir) await writeDirFile(dir, name, bytes);
          else job.pendingSubtitles = [...(job.pendingSubtitles || []), { name, bytes }];
          job.subtitles.push(name);
        },
      });
      await sink.close();
      job.bytes = result.writtenBytes || result.downloadedBytes;
    } catch (error) {
      await sink.abort();
      if (dir) await removeEntry(dir, job.fileName);
      throw error;
    }
    if (cache) await cache.clear();
    if (memory) {
      downloadBlob(memory.toBlob("video/mp4"), job.fileName);
      for (const sub of job.pendingSubtitles || []) {
        downloadBlob(new Blob([sub.bytes], { type: "text/vtt" }), sub.name);
      }
      memory.clear();
    }
    job.status = "done";
    job.detail = dir ? "сохранено в " + (folderNameFor() || state.folderName) : "отправлено в загрузки браузера";
  }

  job.elapsed = Date.now() - job.startedAt;
  job.rate = 0;
  job.eta = 0;
  log(`Серия ${job.number}: готово, ${formatBytes(job.bytes)} за ${formatDuration(job.elapsed / 1000)}`, "ok");
}

async function runJobSafe(job, context) {
  job.status = "wait";
  job.error = "";
  job.detail = "в очереди";
  job.bytes = 0;
  job.segmentsDone = 0;
  job.rate = 0;
  job.eta = 0;
  job.pendingSubtitles = [];
  updateJobRow(job);

  const skipCheck = context.mode === "files" && state.directoryHandle && state.settings.skipExisting;
  if (skipCheck) {
    try {
      const dir = await ensureRunDir();
      const size = await getFileSize(dir, fileNameFor(job));
      if (size > 0) {
        job.status = "skip";
        job.bytes = size;
        job.detail = "уже скачано";
        job.elapsed = 0;
        updateJobRow(job);
        renderOverall();
        return;
      }
    } catch {
      /* просто пробуем скачать */
    }
  }

  try {
    await runJob(job, context);
  } catch (error) {
    if (isAbortError(error) || (context.signal && context.signal.aborted)) {
      job.status = "cancelled";
      job.detail = "отменено";
    } else {
      job.status = "error";
      job.error = String((error && error.message) || error);
      job.detail = job.error;
      log(`Серия ${job.number}: ошибка — ${job.error}`, "ошибка");
    }
  }
  updateJobRow(job);
  renderOverall();
  persistQueue();
  updateBadge();
}

async function runPool(jobs, concurrency, context) {
  let next = 0;
  const count = Math.max(1, Math.min(concurrency, jobs.length));
  const runner = async () => {
    while (!(context.signal && context.signal.aborted)) {
      const index = next++;
      if (index >= jobs.length) return;
      if (context.pause) await context.pause.waitIfPaused();
      if (context.signal && context.signal.aborted) return;
      await runJobSafe(jobs[index], context);
      if (state.settings.politeDelay) await sleep(state.settings.politeDelay);
    }
  };
  await Promise.all(Array.from({ length: count }, () => runner()));
}

async function writeExtras(successful, context) {
  const settings = state.settings;
  const files = successful.filter((job) => job.status === "done" && job.fileName).map((job) => job.fileName);
  const folder = folderNameFor() || state.folderName || "anime";
  const m3uText = settings.writePlaylist && files.length ? buildM3u(files, state.anime ? state.anime.title : "") : "";
  const nfoText = settings.writeNfo ? buildNfo(state.anime || {}, currentGroup(), { quality: qualityValue() }) : "";
  const posterBytes = settings.savePoster ? await fetchPosterBytes() : null;

  if (context.mode === "zip") {
    if (m3uText) await context.zipWriter.addText(folder + ".m3u", m3uText);
    if (nfoText) await context.zipWriter.addText("tvshow.nfo", nfoText);
    if (posterBytes) {
      await context.zipWriter.addEntry({
        name: "poster.jpg",
        size: posterBytes.byteLength,
        crc: crc32(posterBytes),
        chunks: [posterBytes],
      });
    }
    return;
  }

  if (!state.directoryHandle) return;
  const dir = await ensureRunDir();
  if (m3uText) await writeDirFile(dir, sanitizeFilename(folder, "anime") + ".m3u", new TextEncoder().encode(m3uText));
  if (nfoText) await writeDirFile(dir, "tvshow.nfo", new TextEncoder().encode(nfoText));
  if (posterBytes) await writeDirFile(dir, "poster.jpg", posterBytes);
}

function notify(title, message) {
  if (!state.settings.notify || typeof chrome === "undefined" || !chrome.notifications) return;
  try {
    chrome.notifications.create({
      type: "basic",
      iconUrl: chrome.runtime.getURL("icons/icon128.png"),
      title,
      message,
    });
  } catch {
    /* уведомления недоступны */
  }
}

function updateBadge() {
  if (typeof chrome === "undefined" || !chrome.action || !chrome.action.setBadgeText) return;
  try {
    if (!state.running) {
      const failed = state.jobs.filter((job) => job.status === "error").length;
      if (failed) {
        chrome.action.setBadgeText({ text: String(failed) });
        chrome.action.setBadgeBackgroundColor({ color: "#c0392b" });
      } else {
        chrome.action.setBadgeText({ text: "" });
      }
      return;
    }
    const total = state.jobs.length;
    const done = state.jobs.filter((job) => ["done", "skip", "error"].includes(job.status)).length;
    const percent = total ? Math.round((done / total) * 100) : 0;
    chrome.action.setBadgeText({ text: percent + "%" });
    chrome.action.setBadgeBackgroundColor({ color: "#e0457b" });
  } catch {
    /* ignore */
  }
}

function persistQueue() {
  const now = Date.now();
  if (now - state.lastPersist < 500) return;
  state.lastPersist = now;
  const payload = {
    at: now,
    animeId: state.anime ? state.anime.anime_id : 0,
    title: state.anime ? state.anime.title : state.pretitle,
    dub: state.selectedDub,
    quality: state.selectedQuality,
    mode: state.mode,
    episodeKeys: [...state.selectedEpisodes],
    jobs: state.jobs.map((job) => ({
      key: job.key,
      label: job.label,
      fileName: job.fileName,
      status: job.status,
      bytes: job.bytes,
      number: job.number,
      url: job.ep ? job.ep.url : "",
    })),
  };
  saveQueue(payload);
}

async function recordHistory(jobs, aborted) {
  const done = jobs.filter((job) => job.status === "done" || job.status === "skip");
  if (!done.length || aborted) return;
  const bytes = done.reduce((sum, job) => sum + (job.bytes || 0), 0);
  try {
    await idbAddHistory({
      id: Date.now() + "-" + hashString((state.anime ? state.anime.title : "") + "|" + state.selectedDub),
      title: state.anime ? state.anime.title : state.pretitle || "anime",
      dub: state.selectedDub,
      quality: qualityValue(),
      mode: state.mode,
      episodes: done.length,
      bytes,
      at: Date.now(),
      folder: folderNameFor() || state.folderName || "",
      animeId: state.anime ? state.anime.anime_id : 0,
    });
    await renderHistory();
  } catch {
    /* история недоступна */
  }
}

async function startDownloads() {
  if (state.running) return;
  const group = currentGroup();
  if (!group) {
    setError("Сначала выберите тайтл и озвучку.");
    return;
  }
  if (!group.supported) {
    const label = group.playerLabel || "Alloha";
    setError(
      "У этой озвучки видео только в плеере " +
        label +
        ". Откройте плеер кнопкой выше, включите слежение в попапе расширения и запустите серию — поток появится в перехваченных."
    );
    return;
  }
  const episodes = selectedEpisodeObjects();
  if (!episodes.length) {
    setError("Выберите хотя бы одну серию.");
    return;
  }
  if (state.mode === "files" && supportsFileSystemAccess() && !state.directoryHandle) {
    setError("Выберите папку для сохранения — так файлы пишутся сразу на диск.");
    return;
  }
  setError("");
  const settings = await saveSettings({
    quality: state.selectedQuality,
    outputMode: state.mode,
    skipExisting: $("skipExisting") ? $("skipExisting").checked : state.settings.skipExisting,
  });
  state.settings = settings;

  state.running = true;
  state.cancelled = false;
  state.paused = false;
  state.pause = new PauseController();
  state.abort = new AbortController();
  state.runDir = null;
  state.jobs = buildJobs();
  renderJobs();
  updateControls();

  const net = createNet({
    concurrency: settings.concurrency,
    bytesPerSecond: settings.speedLimitKbps * 1024,
  });
  state.net = net;

  const zip = state.mode === "zip";
  let zipSink = null;
  let zipTarget = "";
  if (zip) {
    state.zipName = zipNameFor();
    if (supportsFileSystemAccess() && state.directoryHandle) {
      zipSink = await openFileSink(state.directoryHandle, state.zipName);
      zipTarget = "folder";
    } else {
      zipSink = new MemorySink();
      zipTarget = "downloads";
    }
    state.zipWriter = new ZipWriter({
      sink: zipSink,
      onProgress: (count, bytes) => setText("queueHint", `упаковка: ${count} · ${formatBytes(bytes)}`),
    });
  }

  const context = { mode: state.mode, signal: state.abort.signal, pause: state.pause, net, zipWriter: state.zipWriter };
  state.lastPersist = 0;
  persistQueue();

  log(
    `Старт: ${episodes.length} серий · озвучка «${group.dubbing}» · качество ${qualityLabel()} · ` +
      (zip ? "один ZIP-архив" : "отдельные MP4-файлы") +
      (!zip ? ` · параллельно серий: ${Math.min(settings.episodeConcurrency, episodes.length)}` : "") +
      (settings.speedLimitKbps ? ` · лимит ${settings.speedLimitKbps} КБ/с` : ""),
    "ok"
  );

  let successful = [];
  let runAborted = false;
  try {
    if (zip) {
      for (const job of state.jobs) {
        if (state.abort.signal.aborted) break;
        await state.pause.waitIfPaused();
        await runJobSafe(job, context);
      }
    } else {
      await runPool(state.jobs, settings.episodeConcurrency, context);
    }

    for (let pass = 1; pass <= settings.autoRetry && !state.abort.signal.aborted; pass++) {
      const failedJobs = state.jobs.filter((job) => job.status === "error");
      if (!failedJobs.length) break;
      log(`Автоповтор ${pass}/${settings.autoRetry}: серий с ошибкой — ${failedJobs.length}`, "warn");
      await sleep(1200);
      for (const job of failedJobs) {
        if (state.abort.signal.aborted) break;
        await runJobSafe(job, context);
      }
    }

    const aborted = state.abort.signal.aborted;
    runAborted = aborted;
    successful = state.jobs.filter((job) => job.status === "done" || job.status === "skip");

    if (successful.length && !aborted) {
      try {
        await writeExtras(successful, context);
      } catch (error) {
        log("Не удалось записать плейлист/NFO/постер: " + String((error && error.message) || error), "warn");
      }
    }

    if (zip && state.zipWriter) {
      if (!aborted && successful.length) {
        await state.zipWriter.close();
        await zipSink.close();
        if (zipTarget === "downloads") {
          downloadBlob(zipSink.toBlob("application/zip"), state.zipName);
          zipSink.clear();
        }
        log(`ZIP готов: ${state.zipName}${zipTarget === "folder" ? " — в выбранной папке" : " — отправлен в загрузки браузера"}`, "ok");
      } else {
        await zipSink.abort();
        log("ZIP не собран — загрузка прервана.", "warn");
      }
    }

    await recordHistory(successful, aborted);
  } finally {
    await clearTempDir();
    state.zipWriter = null;
    state.net = null;
    state.running = false;
    state.abort = null;
    updateControls();
    renderOverall();
    updateBadge();
  }

  if (state.cancelled) {
    log("Загрузка остановлена. Кэш сегментов сохранён — при следующем запуске докачаем.", "warn");
    setText("queueHint", "остановлено");
  } else {
    const failed = state.jobs.filter((job) => job.status === "error").length;
    log(failed ? `Готово, но ${failed} серий с ошибкой — нажмите «Повторить серию».` : "Все выбранные серии скачаны.", failed ? "warn" : "ok");
    setText("queueHint", failed ? "с ошибками" : "завершено");
    notify("Download anime videos", failed ? `Готово, но ${failed} серий с ошибкой` : `Скачано серий: ${successful.length}`);
  }
}

async function retryJob(job) {
  if (state.running) return;
  if (state.mode === "zip") {
    setError("Повтор серии недоступен в режиме ZIP — запустите загрузку заново.");
    return;
  }
  state.running = true;
  state.paused = false;
  state.pause = new PauseController();
  state.abort = new AbortController();
  state.net = createNet({
    concurrency: state.settings.concurrency,
    bytesPerSecond: state.settings.speedLimitKbps * 1024,
  });
  updateControls();
  setError("");
  try {
    await runJobSafe(job, {
      mode: state.mode,
      signal: state.abort.signal,
      pause: state.pause,
      net: state.net,
      zipWriter: null,
    });
  } finally {
    state.net = null;
    state.running = false;
    state.abort = null;
    updateControls();
    renderOverall();
    updateBadge();
  }
}

function togglePause() {
  if (!state.running || !state.pause) return;
  if (state.paused) {
    state.pause.resume();
    state.paused = false;
    log("Продолжаем загрузку.", "ok");
  } else {
    state.pause.pause();
    state.paused = true;
    log("Пауза. Текущая серия допишется, следующие ждут.", "warn");
  }
  updateControls();
  renderOverall();
}

function cancelDownloads() {
  if (!state.running) return;
  state.cancelled = true;
  if (state.pause) state.pause.resume();
  if (state.abort) state.abort.abort();
  log("Отменяем загрузку…", "warn");
}

function resolveTheme(theme) {
  if (theme === "dark" || theme === "light") return theme;
  try {
    return globalThis.matchMedia && matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
  } catch {
    return "dark";
  }
}

function applyTheme(theme) {
  document.documentElement.dataset.theme = resolveTheme(theme);
}

if (globalThis.matchMedia) {
  try {
    matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
      if (state.settings && state.settings.theme === "auto") applyTheme("auto");
    });
  } catch {
    /* необязательно */
  }
}

const SETTING_FIELDS = [
  ["setConcurrency", "concurrency", "int"],
  ["setEpisodeConcurrency", "episodeConcurrency", "int"],
  ["setSpeedLimit", "speedLimitKbps", "int"],
  ["setPoliteDelay", "politeDelay", "int"],
  ["setAutoRetry", "autoRetry", "int"],
  ["setFilenameTemplate", "filenameTemplate", "text"],
  ["setFolderTemplate", "folderTemplate", "text"],
  ["setQuality", "quality", "text"],
  ["setTheme", "theme", "text"],
  ["setResume", "resume", "check"],
  ["setSubtitles", "saveSubtitles", "check"],
  ["setPlaylist", "writePlaylist", "check"],
  ["setNfo", "writeNfo", "check"],
  ["setPoster", "savePoster", "check"],
  ["setNotify", "notify", "check"],
];

function renderSettings() {
  for (const [id, key, kind] of SETTING_FIELDS) {
    const node = $(id);
    if (!node) continue;
    if (kind === "check") node.checked = !!state.settings[key];
    else node.value = state.settings[key];
  }
}

function wireSettings() {
  const on = (id, event, handler) => {
    const node = $(id);
    if (node) node.addEventListener(event, handler);
  };
  for (const [id, key, kind] of SETTING_FIELDS) {
    const handler = async () => {
      const node = $(id);
      if (!node) return;
      const value = kind === "check" ? node.checked : kind === "int" ? Number(node.value) : node.value;
      state.settings = await saveSettings({ [key]: value });
      renderSettings();
      if (key === "theme") applyTheme(state.settings.theme);
    };
    on(id, kind === "text" && key.includes("Template") ? "input" : "change", handler);
  }
  on("setClearCache", "click", async () => {
    let removed = 0;
    try {
      const root = await opfsRoot();
      for await (const [name] of root.entries()) {
        if (!String(name).startsWith("ep-")) continue;
        try {
          await root.removeEntry(name, { recursive: true });
          removed++;
        } catch {
          /* пропускаем */
        }
      }
      log(`Кэш сегментов очищен: удалено папок — ${removed}.`, "ok");
    } catch (error) {
      log("Не удалось очистить кэш: " + String((error && error.message) || error), "warn");
    }
  });
  on("historyClearBtn", "click", async () => {
    try {
      await idbClearHistory();
      await renderHistory();
      log("История загрузок очищена.");
    } catch {
      log("Не удалось очистить историю.", "warn");
    }
  });
  on("resumeStartBtn", "click", async () => {
    const bar = $("resumeBar");
    if (bar) bar.hidden = true;
    await startDownloads();
  });
  on("resumeDismissBtn", "click", async () => {
    const bar = $("resumeBar");
    if (bar) bar.hidden = true;
    state.restoreQueue = null;
    await clearQueue();
  });
}

async function renderHistory() {
  const list = $("historyList");
  if (!list) return;
  let items = [];
  try {
    items = await idbListHistory(30);
  } catch {
    items = [];
  }
  state.history = items;
  if (!items.length) {
    list.innerHTML = '<div class="empty">Пока пусто — здесь появятся скачанные сезоны.</div>';
    return;
  }
  list.innerHTML = "";
  for (const item of items) {
    const row = document.createElement("div");
    row.className = "history-row";
    const when = new Date(item.at || Date.now()).toLocaleString("ru-RU");
    row.innerHTML =
      '<div class="history-main"><b></b><span></span></div><div class="history-meta"></div>';
    row.querySelector("b").textContent = item.title || "anime";
    row.querySelector("span").textContent =
      (item.dub ? "«" + item.dub + "» · " : "") + (item.quality ? item.quality + "p · " : "") + (item.mode === "zip" ? "ZIP" : "файлы");
    row.querySelector(".history-meta").textContent =
      when + " · серий: " + (item.episodes || 0) + " · " + formatBytes(item.bytes || 0);
    list.appendChild(row);
  }
}

function showResumeBar(queue) {
  const bar = $("resumeBar");
  if (!bar) return;
  const unfinished = (queue.jobs || []).filter((job) => !["done", "skip"].includes(job.status));
  if (!unfinished.length) return;
  setText(
    "resumeText",
    `Найдена незавершённая загрузка: «${queue.title || "anime"}» — серий: ${queue.jobs.length}, осталось: ${unfinished.length}. Кэш сегментов сохранён, докачаем с места обрыва.`
  );
  bar.hidden = false;
}

function applyPlayerUrl(url, name) {
  const clean = String(url || "").trim();
  if (!/^https?:|^\/\//i.test(clean)) return false;
  const full = clean.startsWith("//") ? "https:" + clean : clean;
  const kind = playerKind(full);
  const label = kind ? kind.label : "встроенный плеер";
  const kodik = !!kind && kind.kind === "kodik";
  state.anime = { anime_id: 0, title: name || "плеер " + label, year: "", poster: state.prePoster || "" };
  state.groups = [
    {
      dubbing: "плеер " + label,
      supported: kodik,
      player: true,
      playerKind: kodik ? "kodik" : kind ? kind.kind : "unknown",
      playerLabel: label,
      episodeCount: 1,
      episodes: [{ number: "1", index: 0, url: full, duration: 0 }],
    },
  ];
  state.selectedDub = state.groups[0].dubbing;
  state.selectedEpisodes = new Set([1]);
  renderAnime();
  renderDubs();
  renderQualities();
  renderEpisodes();
  renderSummary();
  if (kodik) {
    log("Плеер Kodik принят — определим качества и скачаем.", "ok");
    setText("directHint", "Плеер Kodik: ссылка на поток будет получена автоматически.");
    probeQualities().catch(() => {});
  } else {
    log(
      "Плеер " + label + " не отдаёт ссылки напрямую. Включите слежение в попапе расширения на странице плеера, запустите видео — поток появится в перехваченных.",
      "warn"
    );
    setText("directHint", "Плеер " + label + ": нужен перехватчик потоков (попап → «Включить слежение»).");
  }
  return true;
}

function applyDirectUrl(url, name) {
  const clean = String(url || "").trim();
  if (!/^https?:|^\/\//i.test(clean)) return false;
  const full = clean.startsWith("//") ? "https:" + clean : clean;
  state.anime = { anime_id: 0, title: name || "direct-stream", year: "", poster: state.prePoster || "" };
  state.selectedDub = "прямая ссылка";
  state.qualities = [];
  state.selectedQuality = "max";
  state.groups = [
    {
      dubbing: "прямая ссылка",
      supported: true,
      direct: true,
      episodeCount: 1,
      episodes: [{ number: "1", index: 0, url: full, duration: 0 }],
    },
  ];
  state.selectedEpisodes = new Set([1]);
  renderAnime();
  renderDubs();
  renderQualities();
  renderEpisodes();
  renderSummary();
  log("Добавлена прямая ссылка: " + full, "ok");
  return true;
}

const VIEWS = ["viewDownload", "viewWhatsNew"];

function activateView(viewId) {
  const bar = $("tabBar");
  if (!bar || VIEWS.indexOf(viewId) === -1) return;
  for (const tab of bar.querySelectorAll(".tab")) {
    tab.classList.toggle("active", tab.dataset.view === viewId);
  }
  for (const view of document.querySelectorAll(".view")) {
    view.hidden = view.id !== viewId;
  }
  try {
    localStorage.setItem(TAB_KEY, viewId);
  } catch {
    /* приватный режим — просто не запоминаем вкладку */
  }
  if (viewId === "viewWhatsNew") {
    markNewsSeen();
  }
}

function markNewsSeen() {
  try {
    localStorage.setItem(NEWS_SEEN_KEY, "1");
  } catch {
    /* ignore */
  }
  const badge = $("tabBadge");
  if (badge) badge.hidden = true;
}

function initTabs() {
  const bar = $("tabBar");
  if (!bar) return;
  for (const tab of bar.querySelectorAll(".tab")) {
    tab.addEventListener("click", () => activateView(tab.dataset.view));
  }
  let seen = false;
  try {
    seen = localStorage.getItem(NEWS_SEEN_KEY) === "1";
  } catch {
    /* ignore */
  }
  if (seen) markNewsSeen();
  const hash = (location.hash || "").replace(/^#/, "").toLowerCase();
  const wanted =
    hash === "whats-new" || hash === "whatsnew" || hash === "changelog" || params.get("tab") === "whatsnew"
      ? "viewWhatsNew"
      : "";
  let saved = "";
  try {
    saved = localStorage.getItem(TAB_KEY) || "";
  } catch {
    /* ignore */
  }
  const initial = VIEWS.indexOf(wanted) !== -1 ? wanted : VIEWS.indexOf(saved) !== -1 ? saved : VIEWS[0];
  activateView(initial);
}

function wireUi() {
  const on = (id, event, handler) => {
    const node = $(id);
    if (node) node.addEventListener(event, handler);
  };
  on("folderBtn", "click", chooseFolder);
  on("folderPermBtn", "click", grantFolderPermission);
  on("startBtn", "click", startDownloads);
  on("pauseBtn", "click", togglePause);
  on("cancelBtn", "click", cancelDownloads);
  on("clearBtn", "click", () => {
    if (state.running) return;
    state.jobs = [];
    renderJobs();
    updateControls();
  });
  on("searchBtn", "click", () => searchAnime($("searchInput") ? $("searchInput").value : ""));
  on("searchInput", "keydown", (event) => {
    if (event.key === "Enter") searchAnime($("searchInput").value);
  });
  on("epApplyBtn", "click", () => {
    const keys = episodesOfGroup().map(episodeKey);
    const parsed = parseSelection($("epInput") ? $("epInput").value : "", keys);
    if (!parsed) {
      setError("Не понял выбор серий. Пример: 1-12,15");
      return;
    }
    setError("");
    state.selectedEpisodes = parsed;
    renderEpisodes();
    renderQualities();
  });
  on("skipExisting", "change", async () => {
    state.settings = await saveSettings({ skipExisting: $("skipExisting").checked });
  });
  on("copyLogBtn", "click", async () => {
    try {
      await navigator.clipboard.writeText(state.logLines.join("\n"));
      log("Журнал скопирован в буфер обмена.");
    } catch {
      log("Не удалось скопировать журнал.", "warn");
    }
  });
  on("directBtn", "click", () => {
    const input = $("directInput");
    const value = input ? input.value.trim() : "";
    if (!value) {
      setError("Вставьте ссылку на .m3u8, .mp4 или на плеер");
      return;
    }
    setError("");
    const title = (input && input.dataset.title) || "";
    if (/\.(m3u8|mp4|m4v|webm|mov|mpd|ts)(\?|#|$)/i.test(value)) {
      if (!applyDirectUrl(value, title)) setError("Ссылка должна начинаться с http(s)://");
      return;
    }
    if (playerKind(value)) {
      applyPlayerUrl(value, title);
      return;
    }
    if (!applyDirectUrl(value, title)) setError("Ссылка должна начинаться с http(s)://");
  });
  on("openPlayerBtn", "click", async () => {
    const group = currentGroup();
    const url = group && group.episodes[0] ? group.episodes[0].url : "";
    if (!url) return;
    try {
      await background("dav:openPlayer", { url });
      log("Плеер открыт в новой вкладке: включите в попапе «Включить слежение» и запустите серию.", "ok");
    } catch (error) {
      setError(String((error && error.message) || error));
    }
  });
  on("directInput", "keydown", (event) => {
    if (event.key === "Enter") $("directBtn").click();
  });
  on("permBtn", "click", async () => {
    const origins = [...state.pendingOrigins].map((origin) => origin + "/*");
    try {
      const granted = await chrome.permissions.request({ origins });
      if (granted) {
        state.pendingOrigins.clear();
        const bar = $("permBar");
        if (bar) bar.hidden = true;
        log("Доступ выдан — нажмите «Скачать» ещё раз.", "ok");
      } else {
        log("Доступ не выдан.", "warn");
      }
    } catch (error) {
      log("Не удалось запросить доступ: " + String((error && error.message) || error), "warn");
    }
  });

  for (const chip of document.querySelectorAll("#epChips .chip")) {
    chip.addEventListener("click", () => {
      const keys = episodesOfGroup().map(episodeKey);
      if (!keys.length) return;
      const sorted = [...keys].sort((a, b) => a - b);
      const range = chip.dataset.range;
      if (range === "all") state.selectedEpisodes = new Set(sorted);
      else if (range === "first6") state.selectedEpisodes = new Set(sorted.slice(0, 6));
      else if (range === "last6") state.selectedEpisodes = new Set(sorted.slice(-6));
      else if (range === "invert") {
        const current = new Set(state.selectedEpisodes);
        state.selectedEpisodes = new Set(sorted.filter((key) => !current.has(key)));
      } else if (range === "none") state.selectedEpisodes = new Set();
      renderEpisodes();
      renderQualities();
    });
  }

  for (const chip of document.querySelectorAll("#modeChips .chip")) {
    chip.addEventListener("click", async () => {
      if (state.running) return;
      state.mode = chip.dataset.mode;
      for (const other of document.querySelectorAll("#modeChips .chip")) other.classList.toggle("active", other === chip);
      state.settings = await saveSettings({ outputMode: state.mode });
      renderSummary();
      persistQueue();
    });
  }

  wireSettings();
  window.addEventListener("beforeunload", (event) => {
    if (!state.running) return;
    event.preventDefault();
    event.returnValue = "";
  });
}

async function init() {
  setText("versionEl", "v" + chrome.runtime.getManifest().version);
  initTabs();
  state.settings = await loadSettings();
  applyTheme(state.settings.theme);
  const skip = $("skipExisting");
  if (skip) skip.checked = !!state.settings.skipExisting;
  if (state.preMode === "zip" || (!state.preMode && state.settings.outputMode === "zip")) {
    state.mode = "zip";
    for (const chip of document.querySelectorAll("#modeChips .chip")) {
      chip.classList.toggle("active", chip.dataset.mode === "zip");
    }
  }
  state.selectedQuality = state.preQuality || state.settings.quality || "max";
  wireUi();
  renderSettings();
  renderHistory();
  state.streamReferer = state.preReferer;
  if (state.preHdr) {
    try {
      const parsedHeaders = JSON.parse(state.preHdr);
      if (parsedHeaders && typeof parsedHeaders === "object") state.streamHeaders = parsedHeaders;
    } catch {
      log("Не удалось разобрать перехваченные заголовки — качаем как есть.", "warn");
    }
  }
  const directParam = params.get("m3u8") || params.get("url");
  if (state.prePlayer) {
    applyPlayerUrl(state.prePlayer, params.get("title"));
    renderJobs();
    updateControls();
    return;
  }
  if (directParam) {
    applyDirectUrl(directParam, params.get("title"));
    renderJobs();
    updateControls();
    setText("directHint", state.streamReferer ? "Поток из перехватчика — заголовки подставим при загрузке." : "Прямая ссылка загружена.");
    return;
  }
  renderAnime();
  renderDubs();
  renderQualities();
  renderEpisodes();
  renderJobs();
  updateControls();
  if (state.prePoster) updateCandidatePoster(null);
  log("Download anime videos запущен. Только для личного офлайн-просмотра.", "ok");
  if (state.source) log("Источник: " + state.source);

  await restoreFolder();

  try {
    const parsed = state.pretitle ? null : await readSourcePage();
    const resolved = await background("dav:resolve", {
      source: state.source,
      title: state.pretitle || (parsed && parsed.title) || "",
      altTitle: (parsed && parsed.altTitle) || "",
      year: (parsed && parsed.year) || 0,
      animeId: state.preAnimeId,
      animeAlias: state.preAnimeAlias,
    });
    if (resolved && resolved.anime) {
      setText(
        "sourceHint",
        resolved.matchedBy === "id"
          ? "тайтл определён по самой странице"
          : resolved.query
            ? "нашли по названию: " + resolved.query
            : ""
      );
      await selectAnime(resolved.anime.anime_id);
    } else {
      if (parsed && parsed.title) {
        state.pretitle = parsed.title;
        await searchAnime(parsed.title);
        if (state.candidates.length) {
          const best = state.candidates[0];
          if (best.score >= 0.55) await selectAnime(best.anime_id);
        }
      }
      if (!state.anime) {
        renderAnime();
        setText("animeTitle", "Выберите тайтл вручную");
        setText("sourceHint", state.source ? "не удалось определить тайтл по странице" : "");
        const box = $("searchBox");
        if (box) box.open = true;
      }
    }
  } catch (error) {
    setError("Не удалось определить тайтл: " + String((error && error.message) || error));
  }

  try {
    state.restoreQueue = await loadQueue();
  } catch {
    state.restoreQueue = null;
  }
  if (state.restoreQueue && Array.isArray(state.restoreQueue.jobs) && state.restoreQueue.jobs.length) {
    const sameAnime =
      !state.restoreQueue.animeId || !state.anime || state.anime.anime_id === state.restoreQueue.animeId;
    if (sameAnime) {
      if (state.restoreQueue.dub && state.groups.some((group) => group.dubbing === state.restoreQueue.dub)) {
        state.selectedDub = state.restoreQueue.dub;
      }
      if (state.restoreQueue.quality) state.selectedQuality = state.restoreQueue.quality;
      if (Array.isArray(state.restoreQueue.episodeKeys) && state.restoreQueue.episodeKeys.length) {
        state.selectedEpisodes = new Set(state.restoreQueue.episodeKeys);
      }
      renderDubs();
      renderQualities();
      renderEpisodes();
      showResumeBar(state.restoreQueue);
      log("Найдена незавершённая очередь — можно продолжить с докачкой сегментов.", "warn");
    }
  }
  renderSummary();
  updateBadge();
}

init();
