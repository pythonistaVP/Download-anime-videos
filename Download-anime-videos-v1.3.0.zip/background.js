import { createYaniApi, groupVideos, fetchPageInfo, pickBestMatch } from "./lib/yani.js";
import { fetchKodikLinks } from "./lib/kodik.js";
import { detectSite, isKnownSite, playerKind } from "./lib/sites.js";
import { loadSettings, saveSettings, DEFAULT_SETTINGS } from "./lib/settings.js";

const MENU_SEASON = "dav-download-season";
const MENU_PAGE = "dav-download-page";
const SNIFF_PATTERN = /\.(m3u8|mp4|m4v|mpd|webm|mov|flv)(\?|#|$)/i;
const DROP_HEADERS =
  /^(cookie2?|host|connection|content-length|accept-encoding|sec-.*|proxy-.*|te|trailer|transfer-encoding|upgrade|via|priority|pragma|cache-control|if-.*|range|user-agent|referer|origin|forwarded|x-forwarded-.*)$/i;

const sniffed = new Map();

function sniffList(tabId) {
  return sniffed.get(Number(tabId)) || [];
}

function recordSniff(tabId, entry) {
  if (!Number.isFinite(tabId) || tabId < 0) return;
  const list = sniffList(tabId);
  const existing = list.find((item) => item.url === entry.url);
  if (existing) {
    if (entry.headers && Object.keys(entry.headers).length) existing.headers = entry.headers;
    if (entry.referer) existing.referer = entry.referer;
    if (entry.origin) existing.origin = entry.origin;
    return;
  }
  list.push(entry);
  while (list.length > 100) list.shift();
  sniffed.set(tabId, list);
}

const api = createYaniApi({ fetchImpl: (...args) => fetch(...args) });

async function resolveAnime({ source, title, altTitle, year, animeId, animeAlias }) {
  let query = title || altTitle || "";
  let wantedYear = Number(year) || 0;
  let wantedId = Number(animeId) || 0;
  let alias = String(animeAlias || "").trim();
  const site = source ? detectSite(source) : null;

  if (source && (site || !query)) {
    try {
      const parsed = await fetchPageInfo(source, { fetchImpl: (...args) => fetch(...args) });
      query = query || parsed.title || parsed.altTitle || "";
      wantedYear = wantedYear || parsed.year || 0;
      if (!wantedId && parsed.animeId && site && site.idIsApiId) wantedId = parsed.animeId;
      if (!alias && parsed.animeAlias) alias = parsed.animeAlias;
    } catch {
      /* страницу прочитать не удалось — работаем с тем, что дали */
    }
  }

  if (wantedId) {
    try {
      const anime = await api.anime(wantedId);
      if (anime && anime.anime_id) {
        const slug = String(anime.anime_url || "").trim();
        if (!alias || !slug || alias === slug) {
          return { anime, candidates: [], query: anime.title, score: 1, matchedBy: "id" };
        }
      }
    } catch {
      /* идентификатор не совпал — ищем по названию */
    }
  }

  if (!query) return { anime: null, candidates: [], query: "", score: 0, matchedBy: "none" };

  const results = await api.search(query);
  const ranked = pickBestMatch(results, query, wantedYear).filter((entry) => entry.score > 0.25);
  const best = ranked.length ? ranked[0] : null;
  return {
    anime: best ? best.item : null,
    score: best ? best.score : 0,
    candidates: ranked.slice(0, 8).map((entry) => ({ ...entry.item, score: entry.score })),
    query,
    matchedBy: "title",
  };
}

async function loadDubs({ animeId }) {
  const anime = await api.anime(animeId);
  const videos = await api.videos(animeId);
  const groups = groupVideos(videos);
  return {
    anime,
    groups: groups.map((group) => ({
      dubbing: group.dubbing,
      count: group.episodes.length,
      kodikCount: group.kodik.length,
      allohaCount: group.alloha.length,
      supported: group.supported,
      playerKind: group.playerKind,
      playerLabel: group.playerLabel,
      needsSniffer: group.needsSniffer,
      episodes: group.episodes.map((episode) => ({
        number: episode.number,
        index: episode.index,
        url: episode.url,
        duration: episode.duration,
      })),
    })),
  };
}

function buildManagerUrl(params) {
  const query = new URLSearchParams();
  for (const [key, value] of Object.entries(params || {})) {
    if (value === undefined || value === null || value === "") continue;
    query.set(key, String(value));
  }
  return chrome.runtime.getURL("manager.html") + (query.toString() ? "?" + query.toString() : "");
}

async function openManager(params) {
  const url = buildManagerUrl(params);
  await chrome.tabs.create({ url, active: true });
  return url;
}

async function ensureScanner(tabId) {
  if (!chrome.scripting || !chrome.scripting.executeScript) {
    throw new Error("Разрешение scripting недоступно — переустановите расширение");
  }
  await chrome.scripting.executeScript({ target: { tabId, allFrames: false }, files: ["scanner.js"] });
}

function sendToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      const lastError = chrome.runtime.lastError;
      if (lastError) {
        reject(new Error(lastError.message));
        return;
      }
      if (!response || !response.ok) {
        reject(new Error((response && response.error) || "Страница не ответила"));
        return;
      }
      resolve(response.result);
    });
  });
}

async function scanTab(tabId, extra = {}) {
  const id = Number(tabId);
  if (!Number.isFinite(id) || id < 0) throw new Error("Не удалось определить вкладку");
  let scan = null;
  try {
    await ensureScanner(id);
    scan = await sendToTab(id, { type: "dav:scan" });
  } catch (error) {
    throw new Error("Не удалось прочитать страницу: " + String((error && error.message) || error));
  }
  const streams = (scan && scan.streams) || [];
  const players = (scan && scan.players) || [];
  const hls = streams.find((item) => item.kind === "hls") || null;
  const file = streams.find((item) => item.kind === "file") || null;
  const kodik = players.find((item) => item.kind === "kodik") || null;
  const entry = hls || file || kodik;
  if (!entry) {
    throw new Error(
      "На этой странице не нашлось ни потока, ни плеера. Запустите видео и попробуйте ещё раз, либо включите слежение в попапе."
    );
  }
  return { scan, entry, ...extra };
}

async function handleMessage(message, sender) {
  switch (message.type) {
    case "dav:openManager":
      return { url: await openManager(message.params) };
    case "dav:resolve":
      return resolveAnime(message.params || {});
    case "dav:dubs":
      return loadDubs(message.params || {});
    case "dav:probe":
      return fetchKodikLinks(message.params.url, { onLog: null });
    case "dav:settings:get":
      return loadSettings();
    case "dav:settings:set":
      return saveSettings(message.params || {});
    case "dav:defaults":
      return DEFAULT_SETTINGS;
    case "dav:site": {
      const url = String((message.params && message.params.url) || "");
      const site = detectSite(url);
      return { known: !!site, id: site ? site.id : "", label: site ? site.label : "" };
    }
    case "dav:sniff": {
      const tabId = Number((message.params && message.params.tabId) || (sender.tab && sender.tab.id));
      return { streams: sniffList(tabId), permissions: hasWebRequest() };
    }
    case "dav:sniffClear": {
      const tabId = Number((message.params && message.params.tabId) || (sender.tab && sender.tab.id));
      sniffed.delete(tabId);
      return { ok: true };
    }
    case "dav:scan": {
      const tabId = Number((message.params && message.params.tabId) || (sender.tab && sender.tab.id));
      return scanTab(tabId);
    }
    case "dav:openPlayer": {
      const url = String((message.params && message.params.url) || "");
      if (!url) throw new Error("Пустая ссылка на плеер");
      await chrome.tabs.create({ url, active: true });
      return { ok: true };
    }
    case "dav:permissions:request": {
      const origins = (message.params && message.params.origins) || [];
      const permissions = (message.params && message.params.permissions) || ["webRequest"];
      const granted = await chrome.permissions.request({ origins, permissions });
      if (granted) registerSniffer();
      return { granted };
    }
    default:
      throw new Error("Неизвестный запрос: " + message.type);
  }
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (!message || typeof message.type !== "string" || !message.type.startsWith("dav:")) return;
  handleMessage(message, sender)
    .then((result) => sendResponse({ ok: true, result }))
    .catch((error) => sendResponse({ ok: false, error: String((error && error.message) || error) }));
  return true;
});

function createContextMenus() {
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: MENU_SEASON,
      title: "Скачать сезон — Download anime videos",
      contexts: ["page", "link"],
      documentUrlPatterns: [
        "*://yummyanime.tv/*",
        "*://*.yummyanime.tv/*",
        "*://yummyani.me/*",
        "*://*.yummyani.me/*",
        "*://yani.tv/*",
      ],
    });
    chrome.contextMenus.create({
      id: MENU_PAGE,
      title: "Найти видео на этой странице — Download anime videos",
      contexts: ["page"],
      documentUrlPatterns: ["<all_urls>"],
    });
  });
}

chrome.runtime.onInstalled.addListener(async () => {
  createContextMenus();
  const settings = await loadSettings();
  await saveSettings(settings);
});

chrome.runtime.onStartup.addListener(() => {
  createContextMenus();
});

chrome.contextMenus.onClicked.addListener((info, tab) => {
  const target = info.linkUrl && isKnownSite(info.linkUrl) ? info.linkUrl : (tab && tab.url) || "";
  if (info.menuItemId === MENU_SEASON) {
    if (!isKnownSite(target)) return;
    openManager({ source: target, autorun: "1" });
    return;
  }
  if (info.menuItemId === MENU_PAGE) {
    const tabId = tab && tab.id;
    if (Number.isFinite(tabId)) {
      scanTab(tabId)
        .then(({ scan, entry }) => {
          const params = { title: scan.title || (tab && tab.title) || "", poster: scan.poster || "", source: scan.url || "" };
          if (entry.kind === "kodik") params.player = entry.url;
          else params.m3u8 = entry.url;
          return openManager(params);
        })
        .catch(() => openManager({ source: target, title: (tab && tab.title) || "" }));
    }
  }
});

let snifferRegistered = false;

function hasWebRequest() {
  return !!(chrome.webRequest && chrome.webRequest.onBeforeSendHeaders);
}

function keepHeaders(details) {
  const headers = {};
  let referer = "";
  let origin = "";
  for (const header of details.requestHeaders || []) {
    const name = String(header.name || "");
    const value = String(header.value == null ? "" : header.value);
    if (!name || !value) continue;
    const lower = name.toLowerCase();
    if (lower === "referer") {
      referer = value;
      continue;
    }
    if (lower === "origin") {
      origin = value;
      continue;
    }
    if (DROP_HEADERS.test(lower)) continue;
    headers[name] = value;
  }
  return { headers, referer, origin };
}

function handleSniff(details) {
  const url = details.url || "";
  if (!SNIFF_PATTERN.test(url)) return;
  if (!/^https?:/i.test(url)) return;
  const { headers, referer, origin } = keepHeaders(details);
  recordSniff(details.tabId, {
    url,
    kind: /\.m3u8(\?|#|$)/i.test(url) ? "hls" : /\.mpd(\?|#|$)/i.test(url) ? "dash" : "file",
    headers,
    referer,
    origin,
    player: (playerKind(referer) || {}).kind || "",
    at: Date.now(),
  });
}

function registerSniffer() {
  if (snifferRegistered || !hasWebRequest()) return;
  try {
    chrome.webRequest.onBeforeSendHeaders.addListener(
      handleSniff,
      { urls: ["<all_urls>"] },
      ["requestHeaders", "extraHeaders"]
    );
    snifferRegistered = true;
  } catch {
    try {
      chrome.webRequest.onBeforeSendHeaders.addListener(handleSniff, { urls: ["<all_urls>"] }, ["requestHeaders"]);
      snifferRegistered = true;
    } catch {
      /* разрешение webRequest не выдано — слежение недоступно */
    }
  }
}

registerSniffer();

if (chrome.permissions && chrome.permissions.onAdded) {
  chrome.permissions.onAdded.addListener(() => registerSniffer());
}

if (chrome.tabs && chrome.tabs.onRemoved) {
  chrome.tabs.onRemoved.addListener((tabId) => sniffed.delete(tabId));
}

if (chrome.tabs && chrome.tabs.onUpdated) {
  chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
    if (changeInfo.status === "loading" && changeInfo.url) sniffed.delete(tabId);
  });
}
